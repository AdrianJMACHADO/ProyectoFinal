export const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';
export const appTitle = import.meta.env.VITE_APP_TITLE || 'Cine';